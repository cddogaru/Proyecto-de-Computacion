import os
import re
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA
from pmdarima import auto_arima
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import joblib

def parse_metrics(file_path):
    """ Extrae las métricas de evaluación de un archivo de texto y las devuelve en un diccionario.

    Parámetros:
    file_path (str): Ruta del archivo de métricas.

    Retorna:
    dict: Un diccionario con las métricas RMSE, MAE, R² y MAPE.
    
    """
    metrics = {}
    with open(file_path, 'r', encoding='utf-8') as file:
        content = file.read()
         # Extraer métricas utilizando expresiones regulares
        metrics['RMSE'] = float(re.search(r'RMSE:\s([\d\.]+)', content).group(1)) if re.search(r'RMSE:\s([\d\.]+)', content) else None
        metrics['MAE'] = float(re.search(r'MAE:\s([\d\.]+)', content).group(1)) if re.search(r'MAE:\s([\d\.]+)', content) else None
        metrics['R²'] = float(re.search(r'R²:\s([\d\.]+)', content).group(1)) if re.search(r'R²:\s([\d\.]+)', content) else None
        metrics['MAPE'] = float(re.search(r'MAPE:\s([\d\.]+)%', content).group(1)) if re.search(r'MAPE:\s([\d\.]+)%', content) else None
    return metrics

def entrenar_y_guardar_modelo(province, data):
    """
    Entrena un modelo ARIMA para una provincia específica y guarda el modelo y sus métricas.

    Parámetros:
    province (str): Nombre de la provincia a analizar.
    data (DataFrame): Datos históricos del volumen de agua embalsada.
    """
    print(f"Procesando: {province}")

    # Filtrar datos para la provincia específica
    province_data = data[data['PROVINCIA'] == province]['AGUA_ACTUAL']

    # Verificar si hay suficientes datos para entrenar el modelo
    if province_data.empty or province_data.nunique() == 1:
        print(f"{province} no tiene suficientes datos. Saltando...")
        return

    # Resampleo a mensual y completar valores faltantes por interpolación
    province_data = province_data.resample('M').sum().interpolate()
    
    # Auto-ajuste del modelo ARIMA
    model_auto = auto_arima(province_data, seasonal=False, trace=True, error_action='ignore', suppress_warnings=True)
    model_fit = model_auto.fit(province_data)

    # Guardar el modelo entrenado
    os.makedirs("modelos", exist_ok=True)
    model_file = f"modelos/ARIMA_{province}_{pd.Timestamp.now().strftime('%Y%m%d')}.pkl"
    joblib.dump(model_fit, model_file)

    # Evaluar el modelo con datos históricos
    y_pred = model_fit.predict_in_sample()
    rmse = np.sqrt(mean_squared_error(province_data, y_pred))
    mae = mean_absolute_error(province_data, y_pred)
    r2 = r2_score(province_data, y_pred)
    mape = np.mean(np.abs((province_data - y_pred) / province_data)) * 100 if not np.isnan(np.mean(np.abs((province_data - y_pred) / province_data))) else float('inf')

    # Guardar las métricas en un archivo de texto
    os.makedirs("pruebas", exist_ok=True)
    metrics_file = f"pruebas/Metricas_{province}_{pd.Timestamp.now().strftime('%Y%m%d')}.txt"
    with open(metrics_file, 'w', encoding='utf-8') as file:
        file.write(f"RMSE: {rmse}\n")
        file.write(f"MAE: {mae}\n")
        file.write(f"R²: {r2}\n")
        file.write(f"MAPE: {mape:.2f}%\n")

def analyze_directory(directory, output_file, data):
    """
    Analiza todas las métricas almacenadas en archivos de texto dentro de un directorio.

    Parámetros:
    directory (str): Ruta del directorio con archivos de métricas.
    output_file (str): Ruta del archivo de salida con el análisis.
    data (DataFrame): Datos históricos para referencias adicionales.
    """
    
    
    all_metrics = {'RMSE': [], 'MAE': [], 'R²': [], 'MAPE': []}

    # Procesar cada archivo de métricas en el directorio
    for filename in os.listdir(directory):
        if filename.endswith('.txt'):
            file_path = os.path.join(directory, filename)
            try:
                metrics = parse_metrics(file_path)
                for key in all_metrics:
                    if metrics[key] is not None:
                        all_metrics[key].append(metrics[key])
            except Exception as e:
                print(f"Error procesando {filename}: {e}")

    # Calcular promedios de métricas
    averages = {key: (sum(values) / len(values) if values else None) for key, values in all_metrics.items()}
    data_range = data['AGUA_ACTUAL'].max() - data['AGUA_ACTUAL'].min()

    # Función interna para interpretar métricas
    def analyze_metric(metric, avg, range_val):
        if metric == "R²":
            return f"Interpretación: R² indica {'excelente' if avg > 0.9 else 'aceptable' if avg > 0.7 else 'bajo'} ajuste."
        elif metric == "MAPE":
            return f"Interpretación: MAPE es {'excelente' if avg < 10 else 'aceptable' if avg < 20 else 'alto'}."
        else:
            percentage = (avg / range_val) * 100 if range_val else None
            return f"Interpretación: {metric} es {'excelente' if percentage < 10 else 'aceptable' if percentage < 20 else 'alto'} en relación al rango."

    avg_water_per_province = data.groupby('PROVINCIA')['AGUA_ACTUAL'].mean()

    # Guardar resultados en un archivo de texto
    with open(output_file, 'w', encoding='utf-8') as file:
        file.write("Promedio de Agua Embalsada por Provincia:\n")
        for province, avg_water in avg_water_per_province.items():
            file.write(f"{province}: {avg_water:.2f} hm³\n")
        file.write("\nPromedio de Métricas:\n")
        for metric, value in averages.items():
            if value is not None:
                file.write(f"{metric}: {value:.2f}\n")
                file.write(f"{analyze_metric(metric, value, data_range)}\n")
            else:
                file.write(f"{metric}: No hay datos disponibles\n")

def generar_graficas_desde_modelos(data):
    """
    Genera gráficos de predicción ARIMA a partir de modelos guardados.

    Parámetros:
    data (DataFrame): Datos históricos de agua embalsada.
    """

    modelos_dir = 'modelos/'
    resultados_dir = 'resultados/'
    os.makedirs(resultados_dir, exist_ok=True)

    for modelo_nombre in os.listdir(modelos_dir):
        if modelo_nombre.endswith('.pkl'):
            province = modelo_nombre.split('_')[1]
            modelo_path = os.path.join(modelos_dir, modelo_nombre)
            model_fit = joblib.load(modelo_path)

            # Filtramos los datos de la provincia
            province_data = data[data['PROVINCIA'] == province].copy()

            if province_data.empty or len(province_data.dropna()) == 0:
                print(f"No hay datos válidos para {province}, saltando...")
                continue

            # Convertimos la columna 'FECHA' al formato correcto
            province_data['FECHA'] = pd.to_datetime(province_data['FECHA'], dayfirst=True, errors='coerce')
            province_data.set_index('FECHA', inplace=True)

            # Aplicamos resample
            province_data = province_data['AGUA_ACTUAL'].resample('M').sum().interpolate()

            if province_data.empty or len(province_data.dropna()) == 0:
                print(f"Datos insuficientes para generar predicciones en {province}, saltando...")
                continue

            forecast_steps = 12
            forecast = model_fit.predict(n_periods=forecast_steps)

            # Graficamos
            plt.figure(figsize=(12, 6))
            plt.plot(province_data, label='Histórico')
            plt.plot(pd.date_range(start=province_data.index[-1], periods=forecast_steps+1, freq='M')[1:], forecast, label='Predicción', color='red')
            plt.title(f'Predicción ARIMA para {province}')
            plt.xlabel('Fecha')
            plt.ylabel('Volumen de Agua (hm³)')
            plt.legend()
            plt.savefig(os.path.join(resultados_dir, f'Grafico_{province}_Prediccion.png'))
            plt.close()


# Función principal que ejecuta el menú de opciones
def main():
    while True:
        print("\n--- MENÚ PRINCIPAL ---")
        print("1. Ejecutar predicción y análisis completo")
        print("2. Analizar métricas existentes")
        print("3. Generar gráficos desde modelos guardados")
        print("4. Salir")
        opcion = input("Elige una opción: ")

        if opcion == "1":
            os.makedirs('resultados', exist_ok=True)
            os.makedirs('modelos', exist_ok=True)
            os.makedirs('pruebas', exist_ok=True)

            data = pd.read_csv('data/Datos_Embalses_1988_2024.csv', delimiter=';')
            data.columns = data.columns.str.strip()
            data = data.dropna(subset=['PROVINCIA'])
            data['FECHA'] = pd.to_datetime(data['FECHA'], dayfirst=True)
            data.set_index('FECHA', inplace=True)

            unique_provinces = data['PROVINCIA'].unique()
            for province in unique_provinces:
                entrenar_y_guardar_modelo(province, data)

            analyze_directory('pruebas', 'resultados/analisis_resultados.txt', data)
            print("Análisis de métricas completo. Resultados guardados en 'resultados/analisis_resultados.txt'.")

        elif opcion == "2":
            data = pd.read_csv('data/Datos_Embalses_1988_2024.csv', delimiter=';')
            analyze_directory('pruebas', 'resultados/analisis_resultados.txt', data)
            print("Análisis de métricas completo. Resultados guardados en 'resultados/analisis_resultados.txt'.")

        elif opcion == "3":
            data = pd.read_csv('data/Datos_Embalses_1988_2024.csv', delimiter=';')
            generar_graficas_desde_modelos(data)
            print("Gráficos generados en la carpeta 'resultados/'.")

        elif opcion == "4":
            print("Saliendo del programa.")
            break

if __name__ == "__main__":
    main()
