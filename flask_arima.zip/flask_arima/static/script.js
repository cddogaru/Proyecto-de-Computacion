document.addEventListener("DOMContentLoaded", function() {
    const form = document.querySelector("form");
    const submitButton = form.querySelector("button");
    const loadingMessage = document.createElement("div");
    
    loadingMessage.innerHTML = "<p class='loading-text'>Generando predicción... Por favor, espera.</p><div class='spinner'></div>";
    loadingMessage.style.display = "none";
    form.appendChild(loadingMessage);
    
    form.addEventListener("submit", function() {
        submitButton.disabled = true;
        loadingMessage.style.display = "block";
    });
});
