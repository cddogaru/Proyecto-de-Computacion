import os
import pandas as pd
import numpy as np
import joblib
from statsmodels.tsa.arima.model import ARIMA
from pmdarima import auto_arima
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

def entrenar_y_guardar_modelo(province, data):
    """
    Entrena un modelo ARIMA para una provincia y guarda el modelo entrenado y sus métricas.
    """
    print(f"Entrenando modelo para: {province}")

    # Filtrar datos para la provincia
    province_data = data[data['PROVINCIA'] == province]['AGUA_ACTUAL'].resample('M').sum().interpolate()
    
    if province_data.empty or province_data.nunique() == 1:
        print(f"{province} no tiene suficientes datos. Saltando...")
        return
    
    # Ajustar el modelo ARIMA automáticamente
    model_auto = auto_arima(province_data, seasonal=False, trace=True, error_action='ignore', suppress_warnings=True)
    model_fit = model_auto.fit(province_data)
    
    # Guardar modelo entrenado
    os.makedirs("modelos", exist_ok=True)
    model_file = f"modelos/ARIMA_{province}.pkl"
    joblib.dump(model_fit, model_file)
    print(f"Modelo guardado: {model_file}")
    
    # Evaluación del modelo
    y_pred = model_fit.predict_in_sample()
    rmse = np.sqrt(mean_squared_error(province_data, y_pred))
    mae = mean_absolute_error(province_data, y_pred)
    r2 = r2_score(province_data, y_pred)
    mape = np.mean(np.abs((province_data - y_pred) / province_data)) * 100 if not np.isnan(np.mean(np.abs((province_data - y_pred) / province_data))) else float('inf')
    
    # Guardar métricas en un archivo
    os.makedirs("pruebas", exist_ok=True)
    metrics_file = f"pruebas/Metricas_{province}.txt"
    with open(metrics_file, 'w', encoding='utf-8') as file:
        file.write(f"RMSE: {rmse}\n")
        file.write(f"MAE: {mae}\n")
        file.write(f"R²: {r2}\n")
        file.write(f"MAPE: {mape:.2f}%\n")
    print(f"Métricas guardadas en: {metrics_file}")

def main():
    """
    Carga los datos y entrena modelos ARIMA para todas las provincias disponibles.
    """
    data_path = "data/Datos_Embalses_1988_2024.csv"
    if not os.path.exists(data_path):
        print("Error: No se encuentra el archivo de datos.")
        return
    
    data = pd.read_csv(data_path, delimiter=';')
    data.columns = data.columns.str.strip()
    data['FECHA'] = pd.to_datetime(data['FECHA'], dayfirst=True)
    data.set_index('FECHA', inplace=True)
    
    provincias = data['PROVINCIA'].unique()
    for province in provincias:
        entrenar_y_guardar_modelo(province, data)
    
    print("Entrenamiento finalizado.")

if __name__ == "__main__":
    main()
