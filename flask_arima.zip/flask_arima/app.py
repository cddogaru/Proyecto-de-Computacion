from flask import Flask, render_template, request, redirect, url_for
import os
import joblib
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.io as pio
from io import BytesIO
import base64
from entrenar_modelo import entrenar_y_guardar_modelo
from unidecode import unidecode

app = Flask(__name__)




# Cargar datos históricos
data_path = "data/Datos_Embalses_1988_2024.csv"
data = pd.read_csv(data_path, delimiter=';')
data.columns = data.columns.str.strip()
data['FECHA'] = pd.to_datetime(data['FECHA'], dayfirst=True)
data.set_index('FECHA', inplace=True)

# Obtener lista de provincias disponibles

provincias = sorted(data['PROVINCIA'].dropna().astype(str).unique(), key=lambda x: unidecode(x))






@app.route('/', methods=['GET'])
def index():
    """Página principal con selección de provincia."""
    error = request.args.get('error', None)
    return render_template('index.html', provincias=provincias, error=error)

@app.route('/resultados', methods=['POST'])
def resultados():
    """Ejecuta la predicción y muestra los resultados."""
    provincia = request.form.get('provincia')
    if not provincia:
        return redirect(url_for('index', error="Por favor, selecciona una provincia."))

    modelo_path = f'modelos/ARIMA_{provincia}.pkl'

    # Si el modelo no existe, entrenarlo dinámicamente
    if not os.path.exists(modelo_path):
        entrenar_y_guardar_modelo(provincia, data)

    # Verificar nuevamente si el modelo se generó
    if not os.path.exists(modelo_path):
        return redirect(url_for('index', error="No se pudo generar el modelo para la provincia seleccionada."))

    model_fit = joblib.load(modelo_path)
    province_data = data[data['PROVINCIA'] == provincia]['AGUA_ACTUAL'].resample('M').sum().interpolate()

    forecast_steps = 12
    forecast = model_fit.predict(n_periods=forecast_steps)
    fechas_pred = pd.date_range(start=province_data.index[-1], periods=forecast_steps+1, freq='M')[1:]

    # Crear gráfico interactivo con Plotly
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=province_data.index, y=province_data, mode='lines', name='Histórico'))
    fig.add_trace(go.Scatter(x=fechas_pred, y=forecast, mode='lines', name='Predicción', line=dict(color='red', dash='dash')))

    fig.update_layout(title=f'Predicción ARIMA para {provincia}',
                      xaxis_title='Fecha',
                      yaxis_title='Volumen de Agua (hm³)',
                      template='plotly_white')

    # Convertir gráfico a HTML
    graph_html = pio.to_html(fig, full_html=False)
    
   # Cargar métricas desde el archivo de texto
    metrics_file = f'pruebas/Metricas_{provincia}.txt'
    metrics = {}

    if os.path.exists(metrics_file):
        with open(metrics_file, 'r', encoding='utf-8') as file:
            for line in file:
                key, value = line.strip().split(": ")
                try:
                    metrics[key] = f"{float(value):,.2f}"  # Redondear valores a 2 decimales
                except ValueError:
                    metrics[key] = value
    else:
        metrics = {"RMSE": "N/A", "MAE": "N/A", "R²": "N/A", "MAPE": "N/A"}


   # Calcular estadísticas de los datos históricos de la provincia
    province_data = data[data['PROVINCIA'] == provincia]['AGUA_ACTUAL']
    data_std = province_data.std()  # Nuevo: Desviación estándar
    data_mean = province_data.mean()  # Media de los valores históricos
    data_range = province_data.max() - province_data.min()

    # Verificar que el RMSE no sea "N/A"
    if isinstance(metrics["RMSE"], str):
        try:
            metrics["RMSE"] = float(metrics["RMSE"])
        except ValueError:
            metrics["RMSE"] = None

    

    # Calcular RMSE normalizado
    if isinstance(metrics["RMSE"], float) and data_std > 0:
        rmse_percentage = (metrics["RMSE"] / data_std)  # Comparar con std sin multiplicar por 100
        
        
        if rmse_percentage < 1:
            rmse_interpretation = "Excelente precisión (el error es menor que la variabilidad natural)."
        elif rmse_percentage < 2:
            rmse_interpretation = "Buena precisión (el error está dentro de la variabilidad esperada)."
        elif rmse_percentage < 3:
            rmse_interpretation = "Precisión regular (el error es mayor que la variabilidad esperada)."
        else:
            rmse_interpretation = "Precisión baja (el error es muy alto en comparación con los datos)."
    else:
        rmse_interpretation = "No disponible."



    # Asegurar que MAE es un número
    if isinstance(metrics["MAE"], str):
        try:
            metrics["MAE"] = float(metrics["MAE"])
        except ValueError:
            metrics["MAE"] = None

    # Calcular la desviación estándar de los datos históricos
    #data_std = province_data.std()

    # Depuración: imprimir valores antes de calcular el MAE normalizado
    print(f"Provincia: {provincia}")
    print(f"MAE: {metrics['MAE']}")
    print(f"Desviación estándar de los datos históricos: {data_std}")

   # Interpretación dinámica del MAE usando la desviación estándar
    if isinstance(metrics["MAE"], float) and data_std > 0:
        mae_percentage = (metrics["MAE"] / data_std)  # Comparar con std sin multiplicar por 100
        print(f"MAE Normalizado: {mae_percentage}")

        if mae_percentage < 1:
            mae_interpretation = "Excelente precisión (el error es menor que la variabilidad natural)."
        elif mae_percentage < 2:
            mae_interpretation = "Buena precisión (el error está dentro de la variabilidad esperada)."
        elif mae_percentage < 3:
            mae_interpretation = "Precisión regular (el error es mayor que la variabilidad esperada)."
        elif mae_percentage < 5:
            mae_interpretation = "Precisión baja (el error es significativamente mayor que la variabilidad esperada)."
        else:
            mae_interpretation = "Precisión muy baja (el error es extremadamente alto en comparación con los datos)."
    else:
        mae_interpretation = "No disponible."









    # Interpretaciones generales
    interpretations = {
        "RMSE": rmse_interpretation,
        "MAE": mae_interpretation,
        "R²": "Valores cercanos a 1 indican un buen ajuste del modelo.",
        "MAPE": "Un MAPE bajo indica mejor precisión. Menos del 10% es excelente."
    }


    return render_template('resultados.html', provincia=provincia, graph_html=graph_html, metrics=metrics, interpretations=interpretations)



if __name__ == '__main__':
    app.run(debug=True)
